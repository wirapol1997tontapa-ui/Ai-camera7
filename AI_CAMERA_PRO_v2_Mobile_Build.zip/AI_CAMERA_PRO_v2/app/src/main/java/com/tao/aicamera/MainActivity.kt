package com.tao.aicamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import com.google.mlkit.vision.objects.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) recreate()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            askCamera.launch(Manifest.permission.CAMERA)
        }
        setContent { MaterialTheme { CameraHome() } }
    }
}

private enum class SceneMode(val title: String) {
    PEOPLE("คน"), VIEW("วิว"), TRAVEL("เที่ยว"), MOTORCYCLE("มอเตอร์ไซค์")
}

@Composable
private fun CameraHome() {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var mode by remember { mutableStateOf(SceneMode.PEOPLE) }
    var tip by remember { mutableStateOf("จัดตัวแบบให้อยู่ใกล้จุดตัดเส้นสามส่วน") }
    var detected by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var minZoom by remember { mutableFloatStateOf(1f) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var zoomText by remember { mutableStateOf("กำลังอ่านความสามารถกล้อง…") }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    val latestTip = remember { AtomicReference<(String) -> Unit>({}) }
    val latestMode = rememberUpdatedState(mode)
    SideEffect { latestTip.set { tip = it } }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("AI CAMERA PRO", color = Color.Black, fontSize = 20.sp)
            Text("XIAOMI 17 ULTRA", color = Color.DarkGray, fontSize = 11.sp)
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp)) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
                        val future = ProcessCameraProvider.getInstance(ctx)
                        future.addListener({
                            val provider = future.get()
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                            val imageCapture = ImageCapture.Builder()
                                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                                .build()
                            capture = imageCapture
                            val analysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build()
                            val faceDetector = FaceDetection.getClient(
                                FaceDetectorOptions.Builder()
                                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                                    .build()
                            )
                            val objectDetector = ObjectDetection.getClient(
                                ObjectDetectorOptions.Builder()
                                    .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
                                    .enableClassification()
                                    .build()
                            )
                            analysis.setAnalyzer(analysisExecutor) { proxy ->
                                val media = proxy.image
                                if (media == null) { proxy.close(); return@setAnalyzer }
                                val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                                if (latestMode.value == SceneMode.PEOPLE) {
                                    faceDetector.process(input)
                                        .addOnSuccessListener { faces ->
                                            detected = faces.isNotEmpty()
                                            val msg = if (faces.isEmpty()) "ยังไม่พบใบหน้า ลองเล็งไปที่ตัวแบบ" else {
                                                val f = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }!!
                                                val cx = f.boundingBox.centerX().toFloat() / media.width
                                                when {
                                                    cx < 0.38f -> "ตัวแบบอยู่ทางซ้าย ลองจัดให้อยู่ใกล้จุดตัดเส้น"
                                                    cx > 0.62f -> "ตัวแบบอยู่ทางขวา เว้นพื้นที่ด้านหน้าตัวแบบ"
                                                    else -> "พบตัวแบบแล้ว เว้นพื้นที่เหนือศีรษะและอย่าตัดข้อศอก"
                                                }
                                            }
                                            latestTip.get().invoke(msg)
                                        }.addOnCompleteListener { proxy.close() }
                                } else {
                                    objectDetector.process(input)
                                        .addOnSuccessListener { objects ->
                                            detected = objects.isNotEmpty()
                                            val msg = when (latestMode.value) {
                                                SceneMode.VIEW -> "จัดเส้นขอบฟ้าให้อยู่ใกล้เส้น 1/3 และหาเส้นนำสายตา"
                                                SceneMode.TRAVEL -> "วางจุดเด่นใกล้จุดตัดเส้นสามส่วน และเว้นพื้นที่รอบตัวแบบ"
                                                SceneMode.MOTORCYCLE -> if (objects.isNotEmpty()) "เว้นพื้นที่ด้านหน้ารถ และอย่าตัดล้อ" else "ขยับให้เห็นรถทั้งคัน รวมล้อหน้าและล้อหลัง"
                                                else -> "ขยับกล้องช้า ๆ เพื่อหาองค์ประกอบที่สมดุล"
                                            }
                                            latestTip.get().invoke(msg)
                                        }.addOnCompleteListener { proxy.close() }
                                }
                            }
                            try {
                                provider.unbindAll()
                                val bound = provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analysis)
                                camera = bound
                                val z = bound.cameraInfo.zoomState.value
                                minZoom = (z?.minZoomRatio ?: 1f).coerceAtMost(1f)
                                maxZoom = min(120f, z?.maxZoomRatio ?: 1f).coerceAtLeast(1f)
                                zoom = 1f
                                zoomText = if (maxZoom >= 120f) "กล้องรายงานช่วงซูมถึง 120x" else
                                    "กล้องที่แอปเข้าถึงได้สูงสุด ${"%.1f".format(maxZoom)}x"
                            } catch (e: Exception) {
                                zoomText = "เปิดกล้องไม่สำเร็จ: ${e.message ?: "ไม่ทราบสาเหตุ"}"
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )
                CompositionGrid(Modifier.fillMaxSize())
            } else {
                Text("กรุณาอนุญาตให้แอปใช้กล้อง", color = Color.Black, modifier = Modifier.align(Alignment.Center))
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                SceneMode.values().forEach { item ->
                    FilterChip(selected = mode == item, onClick = { mode = item }, label = { Text(item.title, fontSize = 11.sp) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("ZOOM  ${"%.1f".format(zoom)}x", color = Color.Black, fontSize = 16.sp)
                Text(zoomText, color = Color.DarkGray, fontSize = 10.sp)
            }
            Slider(
                value = zoom.coerceIn(minZoom, maxZoom.coerceAtLeast(minZoom)),
                onValueChange = {
                    zoom = it
                    camera?.cameraControl?.setZoomRatio(it)
                },
                valueRange = minZoom..maxZoom.coerceAtLeast(minZoom + 0.01f),
                enabled = camera != null && maxZoom > 1.01f
            )
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                listOf(0.6f, 1f, 2f, 3.2f, 4.3f, 10f, 30f, 60f, 120f).forEach { preset ->
                    val available = preset >= minZoom && preset <= maxZoom
                    OutlinedButton(
                        onClick = {
                            val target = preset.coerceIn(minZoom, maxZoom)
                            zoom = target
                            camera?.cameraControl?.setZoomRatio(target)
                        },
                        enabled = camera != null && available,
                        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 3.dp),
                        modifier = Modifier.weight(1f)
                    ) { Text(preset.toString(), fontSize = 9.sp) }
                }
            }
            Surface(color = Color(0xFFF1F1F1), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(11.dp)) {
                    Text(if (detected) "AI กำลังวิเคราะห์" else "AI COMPOSITION GUIDE", color = Color.Black, fontSize = 11.sp)
                    Text(tip, color = Color.DarkGray, fontSize = 13.sp)
                }
            }
            Button(
                onClick = {
                    val shot = capture
                    if (shot == null) {
                        Toast.makeText(context, "กล้องยังไม่พร้อม", Toast.LENGTH_SHORT).show()
                    } else {
                        val name = "AICamera_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
                        val values = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Camera Pro")
                        }
                        val output = ImageCapture.OutputFileOptions.Builder(
                            context.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
                        ).build()
                        shot.takePicture(output, ContextCompat.getMainExecutor(context),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                                    Toast.makeText(context, "บันทึกภาพแล้วใน Pictures/AI Camera Pro", Toast.LENGTH_LONG).show()
                                }
                                override fun onError(exception: ImageCaptureException) {
                                    Toast.makeText(context, "บันทึกภาพไม่สำเร็จ: ${exception.message}", Toast.LENGTH_LONG).show()
                                }
                            })
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("●  ถ่ายภาพ") }
            Text("AI แนะนำองค์ประกอบเบื้องต้น • Zoom สูงสุดขึ้นกับกล้องที่เครื่องเปิดให้แอป", color = Color.DarkGray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun CompositionGrid(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val x = size.width / 3f
        val y = size.height / 3f
        val line = Color.White.copy(alpha = 0.55f)
        drawLine(line, Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
        drawLine(line, Offset(x * 2, 0f), Offset(x * 2, size.height), 1.dp.toPx())
        drawLine(line, Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
        drawLine(line, Offset(0f, y * 2), Offset(size.width, y * 2), 1.dp.toPx())
        for (px in listOf(x, x * 2)) for (py in listOf(y, y * 2)) {
            drawCircle(Color.White, 5.dp.toPx(), Offset(px, py))
        }
    }
}
