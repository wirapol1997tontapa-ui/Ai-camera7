# AI CAMERA PRO v0.2 — Xiaomi 17 Ultra Android starter

## Included in this build
- CameraX live rear-camera preview
- Rule-of-thirds overlay
- Four scene modes: People, View, Travel, Motorcycle
- ML Kit face detection for People mode
- ML Kit generic object detection in other modes
- Live zoom slider and quick zoom presets (0.6x, 1x, 2x, 3.2x, 4.3x, 10x, 30x, 60x, 120x)
- JPEG capture to `Pictures/AI Camera Pro`

## Important zoom behavior
The app reads `CameraX CameraInfo.zoomState.maxZoomRatio` from the camera exposed by the phone to third-party apps. Presets beyond the reported maximum are disabled. The 120x control is therefore a target, not a guarantee: if HyperOS exposes only a smaller zoom range or hides physical telephoto cameras from third-party apps, the app cannot force native Xiaomi camera behavior. Android's multi-camera selection depends on the device Camera HAL and OEM exposure.

## Build
1. Open this folder in Android Studio (AGP 8.7.3 / Kotlin 1.9.25).
2. Allow Gradle sync to download dependencies.
3. Enable Developer options > USB debugging on the Xiaomi 17 Ultra.
4. Connect the phone and press Run.
5. Grant camera permission.

## Current limitations
- This is a source-code prototype, not a tested APK. It has not been compiled or tested on the user's phone.
- CameraX requests the highest quality capture mode offered by the exposed camera, but this is not guaranteed to match Xiaomi's stock camera app, 50MP/200MP modes, Leica processing, or RAW/DNG.
- ML Kit detection is generic. It does not yet classify motorcycles reliably, detect horizon/pose/leading lines, calculate real subject distance, or provide calibrated left/right/forward/back movement arrows.
- 0.6x and telephoto lens switching depend on what the camera device exposes through Android CameraX/Camera2. Presets are enabled only when they fall within the reported min/max zoom range; actual optical lens switching must still be validated on the phone.
- For full Xiaomi-native camera quality and Photography Kit Pro controls, Xiaomi's stock camera app may retain privileged features unavailable to third-party apps.

## Next engineering step
Run this build on the exact Xiaomi 17 Ultra / HyperOS version and inspect Camera2 camera IDs, logical multi-camera physical IDs, focal lengths, stream sizes, and max zoom. Then implement and validate device-specific lens switching and high-resolution capture.

## UI theme v0.2.1
- Updated app chrome to a clean black-and-white monochrome style: white control panels, black typography and black shutter button; camera preview retains the live scene.


## Build APK using only your Android phone (GitHub Actions)

This project includes `.github/workflows/android-apk.yml` so you can request a cloud build without installing Android Studio on your phone.

1. Sign in to GitHub in your phone browser and create a **new private repository**.
2. Upload the **contents** of this project folder (including the hidden `.github` folder) to the repository's `main` branch. If GitHub mobile web hides the `.github` folder, use the browser's desktop-site option to upload it.
3. Open the repository's **Actions** tab. If prompted, enable Actions.
4. Choose **Build AI CAMERA PRO APK**, then tap **Run workflow** (or wait for the automatic build after pushing to `main`).
5. When the run finishes successfully, open that run, find **Artifacts**, and download `AI-CAMERA-PRO-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone, tap `app-debug.apk`, and allow installation from that source if Android asks.

The cloud workflow builds a **debug APK**. It is not a Play Store release and has not been device-tested. If the build fails, share a screenshot or copy of the error log so it can be fixed.

## Important
A successful cloud build only confirms that Android packaging completed. It does not prove that every camera feature works on Xiaomi 17 Ultra. Lens switching, zoom limits, image quality, and AI guidance still require testing on the actual phone.
